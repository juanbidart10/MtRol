# Prompt de integración — Cards premium MtROL

Trabajá sobre el sistema MtROL ubicado en:

`C:\FoundryVTT\Data\systems\mtrol`

Adjunto dos referencias visuales y dejo en la raíz del repositorio el archivo:

`mtrol-card-emblems-v1.zip`

La primera imagen adjunta es el **objetivo visual definitivo**. La segunda es el
**estado actual corregido**, donde Explosión primordial ya está clasificada como
HECHIZO. Esa clasificación es correcta y no debe volver a tratarse como un bug.

## Objetivo

Integrar los emblemas y llevar todas las cards premium de tirada al lenguaje visual
de la referencia, tanto cerradas como abiertas, sin modificar ninguna regla,
resultado, Roll, fórmula real, crítico, pifia ni desglose existente.

## Reglas obligatorias

1. Antes de editar, auditá el renderer, el registro de assets, el HTML generado y
   el CSS vigente. Reutilizá la infraestructura central existente; no agregues un
   segundo renderer ni lógica paralela.
2. No modifiques el core de Foundry, no evalúes Rolls nuevos, no fabriques datos y
   no reemplaces listeners nativos.
3. Conservá la versión actual de `system.json`. No hagas staging, commit, tag o push.
4. Extraé el ZIP en una carpeta temporal, validá `SHA256SUMS.txt` y copiá únicamente
   `assets/ui/chat/cards-premium/v5/emblems` a la misma ruta dentro del sistema.
   Eliminá la carpeta temporal al terminar; conservá el ZIP original sin seguimiento.
5. Los emblemas son PNG transparentes. No uses `filter`, `drop-shadow`, máscaras,
   recoloreos CSS ni `item.img`. No deformes el recurso. Usá `object-fit: contain`
   y una caja cuadrada de entre 56 y 76 px dentro del medallón superior.

## Selección del emblema

Centralizá una sola resolución de URL en el registro de assets:

- Familia: `attack`, `defense`, `damage`, `healing`, `spell`, `save`, `check` o
  `utility` como fallback.
- Estado: `fumble` tiene prioridad sobre `critical`; en ausencia de ambos, `normal`.
- Ruta: `systems/mtrol/assets/ui/chat/cards-premium/v5/emblems/{state}/{family}.png`.

La familia expresa la naturaleza de la tirada y debe provenir de la clasificación
semántica ya existente. El estado sólo cambia la variante del mismo símbolo. Ejemplo:
un crítico de hechizo usa `critical/spell.png`; una pifia de ataque usa
`fumble/attack.png`. No crees familias `critical` o `fumble`.

## Composición cerrada

Aplicá el mismo esqueleto a todas las familias y estados:

1. Medallón superior con el emblema.
2. Título de la tirada.
3. Cartela con la familia.
4. Fórmula visible.
5. Separador ornamental y rótulo `RESULTADO`.
6. Resultado final centrado dentro del círculo rúnico central.
7. Estado `CRÍTICO` o `PIFIA`, cuando corresponda.
8. Botón integrado `Ver desglose de dados`.

En una columna de chat de aproximadamente 303 px, la card cerrada debe medir entre
430 y 470 px de alto. No debe mostrar scrollbar. Reducí el círculo rúnico entre un
10 % y un 15 %, desplazá el bloque de resultado hacia arriba y aumentá el número
final entre un 10 % y un 15 %. El número nunca debe quedar fuera del círculo central.

El título debe usar Morpheus, mostrarse en mayúsculas visuales y admitir dos líneas
equilibradas sin cortar acentos. No transformes ni reescribas el dato persistente.
El color de título, total, separadores y estado debe provenir de variables de la
familia/estado; no dupliques reglas por card.

La fórmula debe derivarse de la fórmula real y ser sólo una presentación legible:
espacios alrededor de operadores, denominaciones de dados uniformes y nombres de
atributos localizados cuando ya exista esa información. Ejemplo visual:
`1D10 + AURA`, nunca `1D10+AURA`. No agregues, consolides ni elimines modificadores.

El botón debe verse como una única cartela ornamental. Eliminá cualquier rectángulo
CSS exterior, borde blanco/gris, foco persistente o doble marco. Conservá estados
accesibles de `hover` y `focus-visible` acordes con el color de la familia.

Eliminá el pequeño artefacto blanco/gris del borde inferior izquierdo. Encontrá su
causa real (pseudo-elemento, overflow, imagen, scrollbar o estilo heredado); no lo
ocultes con un parche de posición absoluta.

## Composición abierta

Al abrir `Desglose`, conservá el resultado en el círculo central y desplegá debajo
el contenido real del Roll. Todo debe permanecer dentro del marco de la card.

- Usá los nodos y listeners nativos de `.dice-roll` / `.dice-tooltip` ya preparados.
- No dupliques título, fórmula, total ni dados.
- Mostrá una fila por término real de dados y los modificadores reales de la fórmula.
- Dados repetidos deben seguir siendo rastreables de forma individual.
- Las cadenas críticas deben conservar sus grupos y textos reales sin solaparse.
- La zona desplazable debe estar dentro del panel de desglose, no fuera de la card.
- Limitá la altura abierta al espacio visible disponible y aplicá `overflow-y: auto`
  únicamente al cuerpo del desglose. El encabezado, el resultado y el control para
  cerrar deben permanecer visibles.
- Estilizá la scrollbar para que sea discreta y coherente con la familia, sin bordes
  blancos. No ocultes la posibilidad de desplazamiento cuando exista overflow.
- El botón `Ocultar desglose de dados` debe quedar integrado al pie y no superponerse
  al contenido.

## CSS y responsividad

Usá CSS para geometría, espaciado, tipografía, color, estados y scrollbar. Usá los
PNG sólo para marco/fondo ya existentes y para los nuevos emblemas. No generes con
CSS ornamentación que ya esté dibujada en los assets.

Encapsulá todo bajo `.mtrol-roll-card`; no alteres cards de Foundry ni de módulos.
Evitá alturas mágicas por familia. Definí variables reutilizables para color, altura
compacta, diámetro del resultado y dimensión del emblema. Verificá 280, 303 y 340 px
de ancho de chat, y zoom de interfaz 80 %, 100 % y 125 %.

## Aceptación obligatoria

1. Normal, crítico y pifia comparten exactamente la misma geometría.
2. Las ocho familias cargan su emblema correcto en sus tres estados: 24 rutas válidas.
3. Explosión primordial continúa siendo HECHIZO y usa `spell.png`.
4. El resultado final está centrado en el círculo rúnico en card cerrada y abierta.
5. No hay bordes blancos, doble botón, iconos deformados ni artefacto inferior.
6. Cerrada: 430–470 px a 303 px de ancho y sin scrollbar.
7. Abierta: desglose íntegro dentro del marco, scroll interno sólo si hace falta.
8. Fórmula y modificadores coinciden exactamente con los datos reales del Roll.
9. El clic abre/cierra sin crear mensajes, evaluar dados ni perder listeners.
10. Mensajes históricos con Rolls válidos se renderizan; mensajes sin dados no reciben
    un desglose artificial.
11. No hay regresiones en ataque, defensa, daño, curación, salvación, prueba, utilidad,
    iniciativa, localización, cadenas críticas ni pifias.

## Validación y entrega

Agregá o actualizá tests para resolución familia/estado, 24 assets, formato visual de
fórmula, idempotencia, apertura/cierre y ausencia de desgloses fabricados. Ejecutá
`node --check` sobre JavaScript modificado, la suite completa y `git diff --check`.

Hacé una comprobación visual autenticada en Foundry con capturas de:

- Hechizo normal cerrado y abierto.
- Hechizo crítico cerrado y abierto.
- Hechizo con pifia cerrado y abierto.
- Una card de ataque, defensa y curación.
- Un desglose largo que demuestre el scroll interno.

No declares el objetivo visual cumplido sólo porque los tests pasan. Compará las
capturas contra la referencia y reportá medidas, diferencias pendientes y archivos
modificados. Si no podés autenticarte, dejá la validación visual marcada como
pendiente, sin inventar el resultado.
