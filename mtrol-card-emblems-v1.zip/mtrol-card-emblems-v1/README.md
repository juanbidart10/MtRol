# Emblemas premium para las cards de MtROL

Paquete de ocho familias semánticas y tres estados visuales. Los PNG no contienen
texto, círculo, medallón, marco ni fondo: son emblemas transparentes preparados para
ser montados dentro del medallón superior que ya forma parte de la card.

## Familias

- `attack`: espadas cruzadas.
- `defense`: escudo con espada.
- `damage`: hoja fracturada e impacto.
- `healing`: cáliz, gota y hojas.
- `spell`: estrella arcana violeta.
- `save`: nudo de protección.
- `check`: ojo-brújula azul.
- `utility`: llave y herramienta cruzadas.

## Estados

- `normal`: color semántico propio de cada familia.
- `critical`: metal dorado para el estado crítico.
- `fumble`: metal carmesí para la pifia.

La familia representa qué se tiró. El estado representa cómo salió. Por eso una
pifia de hechizo utiliza `fumble/spell.png`, no un emblema genérico de pifia.

## Instalación

Copiar únicamente `assets/ui/chat/cards-premium/v5/emblems` dentro del sistema.
La ruta de Foundry queda definida en `manifest.json`. Los maestros y las previews
son material de edición y control, no recursos de runtime.

Tamaño recomendado dentro del medallón: entre 56 y 76 px, con `object-fit: contain`.
No aplicar filtros CSS, máscaras de recorte ni deformaciones. Mantener relación 1:1.

`SHA256SUMS.txt` permite verificar que ningún PNG fue truncado durante la copia.
