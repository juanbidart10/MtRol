# FINALIZACIÓN DEFINITIVA DE CARDS MTROL

Trabajá sobre `C:\FoundryVTT\Data\systems\mtrol`.

En la raíz del sistema estará `mtrol-cards-static-v5.zip`. Esta tarea reemplaza todas
las instrucciones visuales anteriores que entren en conflicto con este documento.
Debe resolverse en una sola integración, sin crear fases nuevas ni dejar decisiones
visuales abiertas.

## 1. Restricciones absolutas

- No modificar reglas, fórmulas reales, resultados, críticos, pifias ni cadenas.
- No evaluar Rolls nuevos ni crear mensajes adicionales.
- No reemplazar listeners nativos de Foundry.
- No crear un segundo renderer o una plantilla paralela.
- No modificar el core de Foundry.
- No cambiar la versión de `system.json`.
- No hacer staging, commit, tag o push.
- Preservar mensajes históricos e idempotencia.

Auditá primero `chat-roll-card-renderer.js`, el registro de assets, el DOM real y el
CSS premium. Modificá la única fuente vigente.

## 2. Instalar únicamente los marcos finales

Extraé el ZIP temporalmente, validá `SHA256SUMS.txt` y copiá únicamente:

`assets/ui/chat/cards-premium/v5/static`

y:

`assets/ui/chat/cards-premium/v5/components`

a la misma ruta dentro de MtROL. Eliminá el temporal y conservá el ZIP original sin
seguimiento.

Usá estos diez PNG como fondos definitivos. No vuelvas a usar `compact`, `expanded`
o `composite` para abrir/cerrar el desglose. No elimines los assets antiguos hasta
confirmar que ningún consumidor ajeno a estas cards los necesita.

## 3. Card única, sin expansión

El desglose debe estar siempre integrado en la card. Eliminá:

- botón de expansión;
- flecha;
- `aria-expanded`;
- `aria-controls` del toggle;
- `hidden` aplicado al desglose;
- estado `expanded`;
- listener de apertura/cierre;
- footer creado sólo para ese control.

No debe aparecer `Ver desglose de dados` ni `Ocultar desglose de dados`.

## 4. Jerarquía definitiva

El orden visual y semántico es:

1. Medallón y emblema.
2. Categoría.
3. Fórmula real formateada.
4. Rótulo RESULTADO.
5. Total dentro del círculo rúnico.
6. Nombre de habilidad, hechizo o acción debajo del total.
7. Estado CRÍTICO o PIFIA, si existe.
8. Panel permanente DESGLOSE DE DADOS.
9. Dados nativos.
10. Modificadores reales.
11. Cadenas críticas reales.

El nombre no vuelve a la parte superior. Para el ejemplo debe leerse:

`RESULTADO` → `43` → `EXPLOSIÓN PRIMORDIAL`.

No hardcodear títulos ni valores.

## 5. HTML esperado

Adaptá el renderer existente para producir conceptualmente:

```html
<article class="mtrol-roll-card" data-family="spell" data-state="normal">
  <img class="mtrol-roll-card__frame" src="{{frameUrl}}" alt="">

  <header class="mtrol-roll-card__header">
    <figure class="mtrol-roll-card__medallion" aria-hidden="true">
      <img class="mtrol-roll-card__emblem" src="{{emblemUrl}}" alt="">
    </figure>
    <p class="mtrol-roll-card__family">{{familyLabel}}</p>
    <p class="mtrol-roll-card__formula">{{displayFormula}}</p>
  </header>

  <section class="mtrol-roll-card__result">
    <h3 class="mtrol-roll-card__result-label">RESULTADO</h3>
    <div class="mtrol-roll-card__result-circle">
      <output class="mtrol-roll-card__total">{{total}}</output>
    </div>
    <h2 class="mtrol-roll-card__title">{{displayTitle}}</h2>
    {{#if stateLabel}}
      <p class="mtrol-roll-card__state">{{stateLabel}}</p>
    {{/if}}
  </section>

  <section class="mtrol-roll-card__breakdown dice-roll"
           aria-labelledby="{{breakdownTitleId}}">
    <h3 id="{{breakdownTitleId}}"
        class="mtrol-roll-card__breakdown-title">DESGLOSE DE DADOS</h3>
    <div class="mtrol-roll-card__breakdown-body dice-tooltip">
      {{{nativeDiceHtml}}}
      {{#if modifiers.length}}
        <section class="mtrol-roll-card__modifiers">
          <h4>MODIFICADORES</h4>
          <ul>
            {{#each modifiers}}
              <li title="{{sourceLabel}}">{{displayValue}}</li>
            {{/each}}
          </ul>
        </section>
      {{/if}}
      {{#each criticalChains}}
        <section class="mtrol-roll-card__critical-chain">
          {{{nativeRollHtml}}}
        </section>
      {{/each}}
    </div>
  </section>
</article>
```

Es una especificación. Si el renderer produce HTML desde JavaScript, cambiá esa única
fuente. Si usa una plantilla existente, modificá esa plantilla. No crees otra ruta.

## 6. Geometría

Usá el PNG como una capa absoluta de fondo. La card conserva proporción 720/1388 y
debe medir aproximadamente 303 x 584 px a ancho normal de chat. No debe crecer al
interactuar porque no existe expansión.

Distribución aproximada a 303 px:

- medallón y cabecera: 0–155 px;
- resultado y círculo: 150–320 px;
- nombre y estado: 300–380 px;
- desglose permanente: 370–550 px;
- margen inferior ornamental: 34 px.

El panel de desglose puede cubrir visualmente el separador antiguo y la parte baja del
círculo mediante fondo negro casi opaco. No ocultar el marco exterior ni el rombo.

## 7. Emblema

El PNG del emblema está centrado; el problema anterior era CSS. Usá:

```css
.mtrol-roll-card__medallion {
  position: absolute;
  left: 50%;
  top: var(--mtrol-medallion-center-y);
  width: var(--mtrol-medallion-size);
  aspect-ratio: 1;
  transform: translate(-50%, -50%);
  display: grid;
  place-items: center;
  pointer-events: none;
}

.mtrol-roll-card__emblem {
  display: block;
  width: 74%;
  height: 74%;
  margin: 0;
  border: 0;
  object-fit: contain;
  object-position: 50% 50%;
}
```

Podés ajustar entre 70% y 78% tras comparar con la referencia. Una sola geometría por
formato; no offsets diferentes por familia.

## 8. Mapeo de emblemas definitivo

Usá sólo los ocho originales de `emblems/normal`:

- ataque y daño normal → `attack.png`;
- defensa y salvación normal → `defense.png`;
- curación → `healing.png`;
- hechizo → `spell.png`;
- atributo, competencia, prueba e iniciativa → `check.png`;
- utilidad, objeto y fallback → `utility.png`;
- cualquier crítico → `save.png`;
- cualquier pifia → `damage.png`.

Prioridad: pifia, crítico, familia, utility. No usar carpetas recoloreadas `critical`
o `fumble`, filtros CSS ni `item.img`.

## 9. Fórmula, resultado y título

La fórmula es sólo presentación de la fórmula real: `1D10 + AURA`, nunca
`1D10+AURA`. Conservar todos los términos, signos y fuentes.

El total es el foco principal, centrado con Grid dentro del círculo, Morpheus,
`line-height:1` y acabado metalizado mediante variables de familia/estado.

El título queda debajo del total, Morpheus, mayúsculas visuales, tildes preservadas,
18–22 px, máximo dos líneas, `text-wrap: balance` y `line-height:.92`.

## 10. Dados nativos de Foundry

Descartá los SVG personalizados. Si fueron instalados, retiralos sólo tras confirmar
sus consumidores. Reutilizá los nodos nativos existentes de Foundry dentro de
`.dice-roll` y `.dice-tooltip`.

No cambiar geometría, textura ni listeners del dado. Sólo ajustar tamaño a 28–34 px,
alineación y separación. Cada resultado individual debe seguir siendo rastreable.

## 11. Panel permanente y slots vectoriales

El panel debe usar fondo `rgba(4,4,4,.96)`. El borde y las esquinas no se dibujan con
CSS: usá `card-components.svg#breakdown-panel` como SVG absoluto y transparente.

Los cuadros de resultados y modificadores también son assets:

- resultado individual → `card-components.svg#die-value-slot`;
- modificador → `card-components.svg#modifier-slot`.

Insertalos mediante `<svg><use></use></svg>` y colocá el valor HTML por encima. El
`svg` debe usar `color: var(--mtrol-card-accent)`. No uses filtros, border-image,
rectángulos CSS ni backgrounds raster. Los valores continúan siendo texto real.

```css
.mtrol-roll-card__breakdown {
  position: absolute;
  left: var(--mtrol-card-content-gutter);
  right: var(--mtrol-card-content-gutter);
  top: var(--mtrol-breakdown-top);
  bottom: var(--mtrol-breakdown-bottom);
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  min-height: 0;
  background: rgba(4, 4, 4, .96);
}

.mtrol-roll-card__breakdown-body {
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: var(--mtrol-card-accent) transparent;
}
```

- Sin modificadores: no mostrar título ni espacio.
- Sin cadenas: no crear contenedor.
- Sin dados: no fabricar desglose.
- Un término: composición compacta sin espacios artificiales.
- Contenido largo: scroll sólo dentro del cuerpo.

Estructura mínima para cada valor:

```html
<li class="mtrol-roll-card__die-result">
  <svg aria-hidden="true" viewBox="0 0 56 56">
    <use href="systems/mtrol/assets/ui/chat/cards-premium/v5/components/card-components.svg#die-value-slot"></use>
  </svg>
  <span>{{value}}</span>
</li>
```

La misma superposición se aplica a `modifier-slot`. No convertir números en imágenes.

## 12. Paleta y jerarquía

Variables por familia/estado para título, total, bordes y rótulos. Orden visual:

1. total;
2. nombre;
3. resultados individuales;
4. categoría;
5. fórmula;
6. encabezado del desglose;
7. modificadores y textos auxiliares.

Morpheus para identidad, títulos y números; tipografía legible del sistema para datos
pequeños cuando Morpheus pierda claridad.

## 13. Contaminación visual

Los PNG v5 ya eliminan cartela inferior, remaches brillantes y contaminación blanca.
No agregues pseudo-elementos decorativos, puntos, halos, glow, sombras externas,
bordes blancos ni overlays para tapar defectos. Verificá que CSS nativo de `button`,
`img`, `.dice-roll` y `.dice-tooltip` no introduzca bordes o fondos.

## 14. Aceptación

1. Una sola card, sin apertura ni cambio de altura.
2. Desglose siempre integrado.
3. Nombre debajo del total.
4. Resultado centrado.
5. Emblema centrado y con escala equivalente a la referencia.
6. Dados nativos intactos.
7. Modificadores coincidentes con la fórmula real.
8. Pifia y crítico usan los emblemas acordados.
9. No existe cartela, flecha ni texto de expansión.
10. No hay puntos grises, franja blanca, halo o doble borde.
11. No hay secciones vacías.
12. Scroll interno sólo cuando el contenido excede el panel.
13. Mensajes históricos funcionan.
14. No se evalúan Rolls ni se crean mensajes.
15. Todas las familias comparten geometría.

## 15. Validación final obligatoria

Agregá o actualizá pruebas de mapeo, fórmula, dados, modificadores, mensajes sin dados,
idempotencia y ausencia de toggle. Ejecutá `node --check`, suite completa y
`git diff --check`.

Capturas autenticadas requeridas a 303 px:

- hechizo normal;
- ataque;
- defensa;
- crítico;
- pifia;
- varios tipos de dados;
- modificadores positivos y negativos;
- cadena crítica;
- desglose largo con scroll.

Compará cada captura con el objetivo visual. No declarar finalizado si queda un punto
gris, contenido fuera del marco, resultado descentrado, emblema pequeño o sección
vacía. Reportá archivos modificados, medidas finales, pruebas y diferencias restantes.
