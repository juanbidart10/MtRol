# MtROL Cards Static v5

Diez marcos runtime para una card única con desglose permanente.

## Cambios respecto de compact v4

- Se eliminó la cartela inferior de expansión.
- Se eliminaron los puntos claros del interior del medallón.
- Se eliminaron los remaches brillantes de los extremos de la cartela superior.
- Se redujo el halo del canal alfa.
- Se eliminó la contaminación blanca del borde inferior.
- Se preservaron marco, medallón, cartela superior, separadores, círculo rúnico,
  textura negra y rombo inferior.

## Instalación

Copiar `assets/ui/chat/cards-premium/v5/static` y
`assets/ui/chat/cards-premium/v5/components` dentro de la misma ruta del sistema.
No copiar previews ni documentación como recursos runtime.

La card conserva la proporción nativa 720/1388. A 303 px de ancho mide 584 px.
El panel HTML permanente debe ocupar la zona inferior y disponer de scroll interno
sólo para cadenas o desgloses excepcionales.

## Componentes vectoriales

`components/card-components.svg` contiene tres símbolos:

- `#breakdown-panel`: marco transparente del panel inferior.
- `#die-value-slot`: slot cuadrado para un resultado individual.
- `#modifier-slot`: slot rectangular para un modificador.

Se usan con `<svg><use href="...#símbolo"></use></svg>`. El metal hereda
`currentColor`, por lo que sigue la paleta de la card sin filtros ni copias raster.
