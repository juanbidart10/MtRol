MTROL transparent HP/MP icons

Files:
- hp-icon.png
- mp-icon.png

Both PNG files use transparent backgrounds and are intended to replace the current HP and MP icons.
