Trabajá sobre `C:\FoundryVTT\Data\systems\mtrol`. En la raíz estará `mtrol-cards-complete-v10.zip`.

## Instalación

1. Inspeccioná primero el renderer, registro de assets, CSS premium y tests actuales.
2. Descomprimí el ZIP en una carpeta temporal.
3. Validá `manifest.json` y copiá únicamente `assets/ui/chat/cards-premium/v10/` a la misma ruta dentro del sistema.
4. No copies previews ni documentación a runtime.
5. Preservá cambios existentes. No hagas commit, tag ni push.

## Registro único

Reemplazá el registro visual anterior por estas seis claves:

```js
{
  spell: "systems/mtrol/assets/ui/chat/cards-premium/v10/spell.png",
  damagePhysical: "systems/mtrol/assets/ui/chat/cards-premium/v10/damage-physical.png",
  critical: "systems/mtrol/assets/ui/chat/cards-premium/v10/critical.png",
  attack: "systems/mtrol/assets/ui/chat/cards-premium/v10/attack.png",
  defense: "systems/mtrol/assets/ui/chat/cards-premium/v10/defense.png",
  fumble: "systems/mtrol/assets/ui/chat/cards-premium/v10/fumble.png"
}
```

Prioridad de selección:

1. Pifia real → `fumble`.
2. Crítico real → `critical`.
3. Hechizo/magia → `spell`.
4. Daño físico → `damagePhysical`.
5. Defensa, esquiva o bloqueo → `defense`.
6. Ataque restante → `attack`.

No uses `critical` como fallback neutral. Si una tirada no puede clasificarse, usá `attack` y registrá una advertencia de desarrollo sin mostrarla en chat.

## Un único asset por card

Cada PNG es un asset completo de 720 × 1440, renderizado a 303 × 606. Ya contiene marco, textura, medallón, emblema, rótulo de familia, `RESULTADO`, círculo rúnico, panel, `DESGLOSE DE DADOS`, tres guías, `MODIFICADORES` y cuatro cubículos.

El renderer debe crear exactamente un único fondo:

```html
<img class="mtrol-roll-card__art" src="..." alt="">
```

Eliminá capas runtime independientes de emblema, medallón, placa, panel SVG, separadores, encabezados y slots de modificadores. No los reconstruyas mediante CSS, filtros o pseudo-elementos.

## Contenido dinámico permitido

Superponé exclusivamente:

- nombre de la acción/habilidad/hechizo en el área superior vacía;
- fórmula real debajo de la placa de familia;
- total final dentro del círculo;
- dados y resultados reales dentro de las tres guías;
- valores reales dentro de los cuatro cubículos.

Todo usa Morpheus ya instalada y toma el color de acento de la familia.

Si hay menos de cuatro modificadores, dejá vacíos los cubículos restantes. Si hay más de cuatro términos modificadores, agrupá únicamente los compatibles de forma matemática y trazable; no inventes valores ni crees cubículos nuevos. Si no pueden agruparse sin perder información, mostrá un tooltip accesible con el detalle y conservá en los cubículos la suma agrupada.

## Desglose

- Reutilizá los Rolls ya evaluados.
- Cada resultado aparece una sola vez.
- No muestres simultáneamente slot personalizado y valor nativo.
- No repitas `.dice-formula` ni `.dice-total` dentro del panel.
- No renderices `Resultado base sin crítico`, `Crítico en D10`, `[D10: 9 x2]`, emojis, flags, IDs ni diagnóstico técnico.
- Para más de tres filas aplicá densidad compacta dentro del panel; scroll interno sólo como último recurso. La card nunca cambia de altura ni hace scroll global.

## CSS

- Card: `position:relative; width:303px; height:606px; min-height:606px; max-height:606px; overflow:hidden`.
- Arte: absoluto, `inset:0`, `width/height:100%`, `object-fit:fill`, sin borde, fondo, sombra o filtro.
- Contenido dinámico: `position:absolute; z-index:1`.
- Neutralizá pseudo-elementos decorativos heredados dentro de la card con `content:none !important`.
- No agregues fondos, bordes ni sombras a las regiones ya horneadas.

## Pruebas

Verificá:

1. Seis claves exactas y seis PNG existentes.
2. Todos los PNG son 720 × 1440 RGBA.
3. Prioridad pifia > crítico > familia.
4. Una sola imagen de fondo por card.
5. Ausencia de capas estáticas duplicadas.
6. Un único valor visible por dado.
7. Modificadores iguales a la fórmula real.
8. Ausencia de diagnósticos técnicos visibles.
9. Card fija 303 × 606.
10. Mensajes históricos no se reevalúan ni se persisten por renderizado.

Ejecutá suite completa, chequeo de sintaxis y `git diff --check`. Informá archivos modificados, resultados, validaciones runtime pendientes y `git status --short`. No declares paridad visual hasta revisar las seis familias en Foundry como GM y jugador.
