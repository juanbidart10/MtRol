# MtROL Cards completas v10

Seis assets autocontenidos, todos PNG RGBA de 720 × 1440 y destinados a renderizarse a 303 × 606:

| Clave | Archivo | Identidad |
|---|---|---|
| `spell` | `spell.png` | HECHIZO violeta, estrella arcana |
| `damagePhysical` | `damage-physical.png` | DAÑO FÍSICO cobre/carmesí, espada de impacto |
| `critical` | `critical.png` | CRÍTICO dorado, espadas cruzadas |
| `attack` | `attack.png` | ATAQUE azul, espadas cruzadas |
| `defense` | `defense.png` | DEFENSA plateada, escudo |
| `fumble` | `fumble.png` | PIFIA roja, espada rota |

Cada PNG ya contiene todo el arte y todos los textos estáticos. El renderer sólo agrega el nombre, fórmula, total, dados/resultados y valores de modificadores.

No se deben renderizar capas adicionales de marco, medallón, emblema, placa, `RESULTADO`, círculo, panel, encabezados, guías ni cubículos.
