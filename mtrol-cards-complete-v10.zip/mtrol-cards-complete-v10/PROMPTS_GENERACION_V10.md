# Prompts de generación utilizados

Modo: herramienta integrada de generación de imágenes, una edición independiente por variante.

Referencia principal: `spell.png` v9 como master estricto de geometría y composición. Referencia secundaria: cards dorada/roja proporcionadas por el usuario para materiales y lenguaje heráldico.

## Invariantes compartidos

> Create a final production raster shell for a Foundry VTT chat card. Preserve the approved complete card's exact 1:2 proportions, frame silhouette, medallion position, empty title area, plaque position, separator, RESULTADO zone, rune circle, lower panel, exactly three dice-row guides, MODIFICADORES position, and exactly four empty modifier cubicles. Change only identity and palette. Static text baked verbatim: the family label, "RESULTADO", "DESGLOSE DE DADOS", "MODIFICADORES". Dynamic areas remain empty: title, formula, total, dice and modifier values. One flattened complete card, genuine transparent exterior, no white edge, gray dots, extra panels, numbers, dice, watermark or external shadow.

## Variantes

- **DAÑO FÍSICO:** dark iron, oxidized copper and restrained blood-crimson; heavy sword striking a cracked metal plate; plaque `DAÑO FÍSICO`.
- **CRÍTICO:** aged luminous gold/brass without green tint; crossed swords over a radiant critical star; plaque `CRÍTICO`.
- **PIFIA:** blackened steel and deep blood red; clearly broken sword with fractured blade; plaque `PIFIA`.
- **ATAQUE:** midnight blue and tempered blue steel without violet/cyan; crossed swords with a small central blue-steel star; plaque `ATAQUE`.
- **DEFENSA:** aged silver, gunmetal and restrained cool highlights without blue/red/violet dominance; symmetrical silver shield with central sword/rune; plaque `DEFENSA`.
